#include <iostream>
using namespace std;

double division(int a, int b ,int c) {
   if(( a == 0) ||(b==0)||(c==0)) {
      throw "exception : wrong input!!!!!!!!!!!";
   }
   return (a*(1+(b*c)));
}

int main () {
    int p,r,t,z;
    cout<<"enter p,r,t"<<endl;
    cin>>p>>r>>t;
 
 
   try {
      z = division(p,r,t);
      cout << "amounnt ="<< z << endl;
   } catch (const char* msg) {
     cerr << msg << endl;
   }

   return 0;
}